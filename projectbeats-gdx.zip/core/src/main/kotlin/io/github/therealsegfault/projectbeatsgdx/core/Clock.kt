package io.github.therealsegfault.projectbeatsgdx.core

fun interface Clock {
  fun nowSeconds(): Double
}
