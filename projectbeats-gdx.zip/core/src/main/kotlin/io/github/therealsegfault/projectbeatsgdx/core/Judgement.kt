package io.github.therealsegfault.projectbeatsgdx.core

enum class Judgement {
  PERFECT,
  COOL,
  FINE,
  SAD,
  MISS
}
