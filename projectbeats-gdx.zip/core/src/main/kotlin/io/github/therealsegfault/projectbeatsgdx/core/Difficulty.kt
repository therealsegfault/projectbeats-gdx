package io.github.therealsegfault.projectbeatsgdx.core

enum class Difficulty {
  EASY,
  NORMAL,
  HARD,
  EXTREME
}
